# Ekart multi-courier tracking starter

This is a secure-by-default starter project, not a finished live courier integration. The UI and API shell work, but each provider adapter deliberately returns a clear setup error until its exact approved endpoint, authentication, request shape, and response mapping have been implemented.

## Requirements
- Node.js 20+
- API documentation/access for each courier account
- A hosting account and a domain registered in your business's name

## Run locally
1. Extract this folder.
2. Copy `.env.example` to `.env`.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

Do not set `ALLOW_DEMO` to true; the current starter has no fake tracking mode. It never pretends a tracking number has a real status.

## Connect each courier
Edit `src/carriers/index.js` and `src/carriers/json-carrier.js`, or implement dedicated adapters such as `src/carriers/indiapost.js`, `dtdc.js`, `delhivery.js`, and `bluedart.js`.

For each carrier, confirm from your own approved developer documentation:
- Exact production base URL and endpoint
- HTTP method and query/body parameters
- Authentication method, headers, token expiry/refresh rules
- Tracking response schema and error codes
- Rate limits, IP allowlisting, and permitted usage
- Whether webhooks are available

Map the provider response to this normalized shape:
```js
{
  carrier: "delhivery",
  carrierName: "Delhivery",
  trackingNumber: "TRACKING_NUMBER",
  status: "In transit",
  events: [
    { status: "Shipment picked up", location: "Origin hub", timestamp: "2026-10-22T10:30:00+05:30" }
  ]
}
```
The example above is a shape example only, not live tracking data.

## Security checklist
- Never commit `.env`; keep credentials in the hosting dashboard's secret/environment settings.
- Do not put carrier credentials in browser JavaScript.
- Add authenticated admin endpoints only after implementing a real authentication provider.
- Add persistent database storage, audit logs, privacy policy, and backup plan before production launch.
- Keep rate limits and validate tracking-number input.
- Do not store personal recipient details unless genuinely needed and covered by your privacy policy.

## Hosting/domain outline
1. Push the project to a private GitHub repository.
2. Create a Render Web Service connected to the repository.
3. Build command: `npm install`; start command: `npm start`.
4. Add each secret in Render's Environment settings (do not paste it into source files).
5. Register a `.in` domain with a registrar accredited by the .IN Registry.
6. In Render, open the service's Settings → Custom Domains, add your domain, and follow the exact DNS records shown in the dashboard.
7. Verify HTTPS, logs, health endpoint (`/api/health`), and each courier's test tracking number before public launch.

## Important naming note
“Ekart” is already used as a logistics/commerce brand in India. Before purchasing a domain or launching, check trademark rights and avoid implying affiliation with another company. Consider a distinct name if you are not authorized to use that brand.
