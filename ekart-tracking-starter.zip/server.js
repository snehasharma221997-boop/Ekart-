import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { trackShipment, supportedCarriers } from './src/tracking.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 3000);

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: {
  directives: {
    defaultSrc: ["'self'"],
    styleSrc: ["'self'", "'unsafe-inline'"],
    scriptSrc: ["'self'"],
    imgSrc: ["'self'", 'data:'],
    connectSrc: ["'self'"],
    objectSrc: ["'none'"],
    upgradeInsecureRequests: process.env.NODE_ENV === 'production' ? [] : null
  }
}}));
app.use(express.json({ limit: '10kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/health', (_req, res) => res.json({ ok: true, app: process.env.APP_NAME || 'Ekart Parcel Tracking' }));
app.get('/api/carriers', (_req, res) => res.json({ carriers: supportedCarriers }));

app.get('/api/track/:trackingNumber', async (req, res) => {
  const trackingNumber = String(req.params.trackingNumber || '').trim();
  const carrier = String(req.query.carrier || 'auto').toLowerCase();
  if (!/^[A-Za-z0-9-]{5,40}$/.test(trackingNumber)) {
    return res.status(400).json({ error: 'Enter a valid tracking number (5–40 letters, numbers or hyphens).' });
  }
  if (carrier !== 'auto' && !supportedCarriers.some(c => c.id === carrier)) {
    return res.status(400).json({ error: 'Unsupported courier selection.' });
  }
  try {
    const result = await trackShipment({ trackingNumber, carrier });
    if (!result) return res.status(404).json({ error: 'No tracking result found. Check the number and courier.' });
    return res.json(result);
  } catch (err) {
    const status = err.statusCode || 502;
    return res.status(status).json({ error: err.publicMessage || 'The courier tracking service is unavailable. Please try again later.' });
  }
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(port, '0.0.0.0', () => {
  console.log(`${process.env.APP_NAME || 'Ekart Parcel Tracking'} listening on ${port}`);
});
