const form = document.querySelector('#track-form');
const input = document.querySelector('#tracking');
const carrier = document.querySelector('#carrier');
const button = document.querySelector('#track-button');
const message = document.querySelector('#message');
const result = document.querySelector('#result');
document.querySelector('#year').textContent = new Date().getFullYear();

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const trackingNumber = input.value.trim();
  message.hidden = true;
  result.hidden = true;
  button.disabled = true;
  button.querySelector('span').textContent = 'Checking…';
  try {
    const response = await fetch(`/api/track/${encodeURIComponent(trackingNumber)}?carrier=${encodeURIComponent(carrier.value)}`);
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Tracking lookup failed.');
    renderResult(data);
  } catch (err) {
    message.textContent = err.message || 'Could not connect. Please try again.';
    message.hidden = false;
  } finally {
    button.disabled = false;
    button.querySelector('span').textContent = 'Track parcel';
  }
});

function renderResult(data) {
  result.replaceChildren();
  const title = document.createElement('h2');
  title.textContent = 'Shipment details';
  const meta = document.createElement('p');
  meta.className = 'result-meta';
  meta.textContent = `${data.carrierName || data.carrier} · Tracking number: ${data.trackingNumber}`;
  const pill = document.createElement('span');
  pill.className = 'status-pill';
  pill.textContent = data.status || 'Status unavailable';
  result.append(title, meta, pill);
  const events = document.createElement('div');
  events.className = 'events';
  (data.events || []).forEach(item => {
    const event = document.createElement('div');
    event.className = 'event';
    const strong = document.createElement('strong');
    strong.textContent = item.status || 'Shipment update';
    const small = document.createElement('small');
    small.textContent = [item.location, item.timestamp].filter(Boolean).join(' · ');
    event.append(strong, small);
    events.append(event);
  });
  if (!events.children.length) {
    const noEvents = document.createElement('p');
    noEvents.className = 'result-meta';
    noEvents.textContent = 'The courier returned no event history.';
    events.append(noEvents);
  }
  result.append(events);
  result.hidden = false;
}
