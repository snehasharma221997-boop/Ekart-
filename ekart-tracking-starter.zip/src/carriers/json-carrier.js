// Template for a JSON tracking API. This intentionally fails closed until the
// carrier's endpoint and response mapping are implemented and tested.
export function createJsonCarrier({ id, name, baseEnv, tokenEnv }) {
  return {
    id, name,
    async track(trackingNumber) {
      const base = process.env[baseEnv];
      const token = process.env[tokenEnv];
      if (!base || !token) {
        const err = new Error(`${name} API is not configured.`);
        err.statusCode = 503;
        err.publicMessage = `${name} tracking is not connected yet. Please choose another courier or try again later.`;
        throw err;
      }

      // SAFETY: Replace this generic URL and Bearer authentication only after
      // checking the carrier's approved API documentation. Do not invent paths.
      // Implement each provider's exact request and response mapping separately.
      const err = new Error(`${name} adapter needs provider-specific implementation.`);
      err.statusCode = 501;
      err.publicMessage = `${name} credentials are present, but its API adapter needs to be configured for the provider's approved endpoint and response format.`;
      throw err;
    }
  };
}
