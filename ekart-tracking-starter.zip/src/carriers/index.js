import { createJsonCarrier } from './json-carrier.js';

// IMPORTANT: Generic adapter scaffold only. Confirm each carrier's actual
// endpoint, authentication scheme, request format, and response mapping first.
// Do not assume all four APIs use Bearer tokens or the same JSON schema.
export const carriers = [
  createJsonCarrier({
    id: 'indiapost', name: 'India Post',
    baseEnv: 'INDIAPOST_API_BASE', tokenEnv: 'INDIAPOST_API_TOKEN'
  }),
  createJsonCarrier({
    id: 'dtdc', name: 'DTDC',
    baseEnv: 'DTDC_API_BASE', tokenEnv: 'DTDC_API_TOKEN'
  }),
  createJsonCarrier({
    id: 'delhivery', name: 'Delhivery',
    baseEnv: 'DELHIVERY_API_BASE', tokenEnv: 'DELHIVERY_API_TOKEN'
  }),
  createJsonCarrier({
    id: 'bluedart', name: 'Blue Dart',
    baseEnv: 'BLUEDART_API_BASE', tokenEnv: 'BLUEDART_API_TOKEN'
  })
];
