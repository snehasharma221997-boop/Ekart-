import { carriers } from './carriers/index.js';

export const supportedCarriers = carriers.map(({ id, name }) => ({ id, name }));

export async function trackShipment({ trackingNumber, carrier }) {
  const selected = carrier === 'auto' ? carriers : carriers.filter(c => c.id === carrier);
  const failures = [];
  for (const adapter of selected) {
    try {
      const result = await adapter.track(trackingNumber);
      if (result) return result;
    } catch (error) {
      failures.push(error);
      // For explicit carrier selection, don't silently try another carrier.
      if (carrier !== 'auto') throw error;
    }
  }
  if (failures.length && carrier === 'auto') {
    const err = new Error('No courier could confirm this tracking number.');
    err.statusCode = 502;
    err.publicMessage = 'We could not confirm this tracking number with the connected couriers. Check the number or choose the courier.';
    throw err;
  }
  return null;
}
